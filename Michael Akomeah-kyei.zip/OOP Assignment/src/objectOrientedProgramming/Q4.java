package objectOrientedProgramming;

import java.util.Scanner;

public class Q4 {
	/*Write a program to print the area of a rectangle by creating a class named 'Area' taking
	the values of its length and breadth as parameters of its constructor and having a
	method named 'returnArea' which returns the area of the rectangle. The length and
	breadth of the rectangle are entered through the keyboard.
	*/
	
	public static void main(String[] args) {
		Scanner Scan = new Scanner(System.in);
		System.out.println("Enter length of the rectangle: ");
		int length =Scan.nextInt();
		System.out.println("Enter breadth of the rectangle: ");
		int breadth = Scan.nextInt();
		
		Area A =  new Area(length,breadth);
	System.out.println("The area of the Rectangle: " +	A.returnArea());
		
		
	}
}

class Area{
public int length;
 public int breadth;

Area (int l,int b){
	this.length =  l;
	this.breadth = b;	
	

}
 public int returnArea(){
	return length*breadth;		
}

	
	
}