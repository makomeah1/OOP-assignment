package objectOrientedProgramming;

public class Q2 {
	

	
/*Write a program to print the area and perimeter of a triangle having sides of 3, 4, and 5
units by creating a class named 'Triangle' without any parameter in its constructor.
*/
	public static void main(String[] args) {
		
		Triangle S = new Triangle();
		     System.out.println("Perimeter of A triangle with sides 3,4,5 : " + S.Perimeter);
		     System.out.println("The Area of the triangle: " + S.Area);
	}
	
	
	}
	class Triangle {
		int firstSide;
		int secondSide;
		int thirdSide;
		double Area;
		int Perimeter;
		
		public Triangle() {
			firstSide =3;
			secondSide=4;
			thirdSide =5;
			
			//since the sides are 3,4,5 the triangle is right angle triangle
			Area =(secondSide*firstSide)/2;
			Perimeter = firstSide + secondSide + thirdSide;
		}
		

		}
		
	

	
	
			

		
		
	
	


