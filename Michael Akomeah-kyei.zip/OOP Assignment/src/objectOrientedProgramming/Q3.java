package objectOrientedProgramming;

public class Q3 {
	/*Write a program to print the area of two rectangles having sides (4,5) and (5,8)
	respectively by creating a class named 'Rectangle' with a method named 'Area' which
	returns the area and length and breadth passed as parameters to its constructor.
     */
	
	public static void main(String[] args) {
		rectangle Rec = new rectangle(4,5);
		rectangle Rec2 = new rectangle(5,8);		
	}
}
class rectangle{
	int length;
	int breadth;
	
	rectangle(int l,int b){
		this.length= l;
		this.breadth=b;
		
	System.out.println("The area of the rectanle is: "+l*b);
		
	}	
}