package objectOrientedProgramming;

public class Q1 {
	
/* Create a class named 'Student' with the String variable 'name' and integer variable
'roll_no'. Assign the value of roll_no as '2' and that of the name as "John" by creating an
object of the class Student.
*/	
	public static void main(String [] args) {
		Student  Se = new Student("John", 2);
		Se.display();
	}
		
}

class Student{
	String name;
	int roll_no;
	
	Student (String n, int r){
		name = n;
		roll_no =r;		
	}
	
	void display() {
		System.out.println(roll_no + " " + name);
	}
	
}




	
